kiwi.bootloader.template Package
================================

.. _db_kiwi_bootloader_template_submodules:

Submodules
----------

`kiwi.bootloader.template.grub2` Module
---------------------------------------

.. automodule:: kiwi.bootloader.template.grub2
    :members:
    :undoc-members:
    :show-inheritance:

`kiwi.bootloader.template.isolinux` Module
------------------------------------------

.. automodule:: kiwi.bootloader.template.isolinux
    :members:
    :undoc-members:
    :show-inheritance:

.. _db_kiwi_bootloader_template_content:

Module Contents
---------------

.. automodule:: kiwi.bootloader.template
    :members:
    :undoc-members:
    :show-inheritance:
