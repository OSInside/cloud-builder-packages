kiwi.storage.subformat Package
==============================

.. _db_kiwi_storage_subformat_submodules:

Submodules
----------

`kiwi.storage.subformat.base` Module
------------------------------------

.. automodule:: kiwi.storage.subformat.base
    :members:
    :undoc-members:
    :show-inheritance:

`kiwi.storage.subformat.gce` Module
-----------------------------------

.. automodule:: kiwi.storage.subformat.gce
    :members:
    :undoc-members:
    :show-inheritance:

`kiwi.storage.subformat.ova` Module
-----------------------------------

.. automodule:: kiwi.storage.subformat.ova
    :members:
    :undoc-members:
    :show-inheritance:

`kiwi.storage.subformat.qcow2` Module
-------------------------------------

.. automodule:: kiwi.storage.subformat.qcow2
    :members:
    :undoc-members:
    :show-inheritance:

`kiwi.storage.subformat.vagrant_base` Module
--------------------------------------------

.. automodule:: kiwi.storage.subformat.vagrant_base
    :members:
    :undoc-members:
    :show-inheritance:

`kiwi.storage.subformat.vagrant_libvirt` Module
-----------------------------------------------

.. automodule:: kiwi.storage.subformat.vagrant_libvirt
    :members:
    :undoc-members:
    :show-inheritance:

`kiwi.storage.subformat.vagrant_virtualbox` Module
--------------------------------------------------

.. automodule:: kiwi.storage.subformat.vagrant_virtualbox
    :members:
    :undoc-members:
    :show-inheritance:

`kiwi.storage.subformat.vdi` Module
-----------------------------------

.. automodule:: kiwi.storage.subformat.vdi
    :members:
    :undoc-members:
    :show-inheritance:

`kiwi.storage.subformat.vhd` Module
-----------------------------------

.. automodule:: kiwi.storage.subformat.vhd
    :members:
    :undoc-members:
    :show-inheritance:

`kiwi.storage.subformat.vhdfixed` Module
----------------------------------------

.. automodule:: kiwi.storage.subformat.vhdfixed
    :members:
    :undoc-members:
    :show-inheritance:

`kiwi.storage.subformat.vhdx` Module
------------------------------------

.. automodule:: kiwi.storage.subformat.vhdx
    :members:
    :undoc-members:
    :show-inheritance:

`kiwi.storage.subformat.vmdk` Module
------------------------------------

.. automodule:: kiwi.storage.subformat.vmdk
    :members:
    :undoc-members:
    :show-inheritance:

.. _db_kiwi_storage_subformat_content:

Module Contents
---------------

.. automodule:: kiwi.storage.subformat
    :members:
    :undoc-members:
    :show-inheritance:
