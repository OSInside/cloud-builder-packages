KIWI - Boxed Build Plugin
=========================

.. |GitLab CI Pipeline| image:: https://gitlab.com/kiwi3/kiwi-boxed-plugin/badges/master/pipeline.svg
   :target: https://gitlab.com/kiwi3/kiwi-boxed-plugin/-/pipelines

|GitLab CI Pipeline|

KIWI plugin to provide self contained build support. For further
details see:

`Building in a Self-Contained Environment <https://osinside.github.io/kiwi/self_contained.html>`__
